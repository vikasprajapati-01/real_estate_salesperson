
// Grok client using the official xAI Responses API.

const BASE_URL = process.env.XAI_BASE_URL ?? "https://api.x.ai/v1";

const MODEL = process.env.GROK_MODEL ?? "grok-4.7";

export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

export type GenerateParams = {
  system: string;
  messages: ChatMessage[];
  json?: boolean;
  temperature?: number;
  maxTokens?: number;
};

class GrokError extends Error {
  constructor(public status: number | undefined, message: string) {
    super(message);
  }
}

export async function generate(p: GenerateParams): Promise<string> {
  const key = process.env.XAI_API_KEY?.trim();

  if (!key) {
    throw new GrokError(401, "XAI_API_KEY is missing in .env.local");
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 60000);

  try {
    const res = await fetch(`${BASE_URL}/responses`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: MODEL,
        input: [
          {
            role: "system",
            content:
              p.system +
              (p.json
                ? "\n\nReturn ONLY a valid JSON object. Do not include markdown fences or additional text."
                : ""),
          },
          ...p.messages,
        ],
        max_output_tokens: p.maxTokens ?? 4096,
      }),
      signal: ctrl.signal,
    });

    if (!res.ok) {
      const errorText = await res.text();
      throw new GrokError(res.status, errorText.slice(0, 1000));
    }

    const data = await res.json();

    // Extract text from the Responses API output.
    const outputText =
      data.output
        ?.filter((item: any) => item.type === "message")
        ?.flatMap((item: any) => item.content ?? [])
        ?.filter((item: any) => item.type === "output_text")
        ?.map((item: any) => item.text)
        ?.join("\n") ?? "";

    if (!outputText) {
      throw new GrokError(502, "Grok returned an empty response");
    }

    console.log(`Grok OK: ${MODEL}`);

    return outputText;
  } catch (e) {
    if (e instanceof GrokError) {
      console.error("Grok API error:", e.status, e.message);
      throw e;
    }

    throw new GrokError(
      504,
      e instanceof Error ? e.message : "Network error"
    );
  } finally {
    clearTimeout(timer);
  }
}
